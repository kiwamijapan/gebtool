import tkinter as tk
from tkinter import filedialog, messagebox
from tools.kreskomat import codes_main

class KeyDescriptionApp:
    def __init__(self, root):
        self.root = root
        self.root.title("Generator kodow kreskowych")

        self.key_label = tk.Label(root, text="NAZWA MASZYNY")
        self.key_label.grid(row=0, column=0, padx=10, pady=10)

        self.description_label = tk.Label(root, text="SAP ID (E......)")
        self.description_label.grid(row=0, column=1, padx=10, pady=10)

        self.key_text = tk.Text(root, height=10, width=40)
        self.key_text.grid(row=1, column=0, padx=10, pady=10)

        self.description_text = tk.Text(root, height=10, width=40)
        self.description_text.grid(row=1, column=1, padx=10, pady=10)

        self.generate_button = tk.Button(root, text="Wygeneruj kody", command=self.generate_file)
        self.generate_button.grid(row=2, column=0, columnspan=2, pady=10)

    def generate_file(self):
        keys = self.key_text.get("1.0", tk.END).strip().split('\n')
        descriptions = self.description_text.get("1.0", tk.END).strip().split('\n')

        if len(keys) != len(descriptions):
            messagebox.showerror("Error", "Liczba argumentow musi byc taka sama z obu stron.")
            return

        lines = [f"{key} {description}" for key, description in zip(keys, descriptions)]
        codes_main(lines)
        messagebox.showinfo("OK", "Kody kreskowe wygenerowane w folderze Barkody. ")

if __name__ == "__main__":
    root = tk.Tk()
    app = KeyDescriptionApp(root)
    root.mainloop()
