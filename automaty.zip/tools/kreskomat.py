import barcode
from barcode.writer import ImageWriter
from PIL import Image, ImageDraw, ImageFont
import os
from io import BytesIO
import unidecode

def generate(data_list, text_list, output_directory, num_columns=3, padding=20):
    images = []
    for data, text in zip(data_list, text_list):
        code = barcode.get_barcode_class('code128')
        my_code = code(data, writer=ImageWriter())
        barcode_img = BytesIO()
        my_code.write(barcode_img, options={'write_text': False})
        img = Image.open(barcode_img)
        img = resize(img, text, padding)
        images.append(img)

    a4_width = 8.27 * 300
    a4_height = 11.7 * 300

    num_rows = (len(images) + num_columns - 1) // num_columns
    barcode_width = (a4_width - (num_columns + 1) * padding) / num_columns
    barcode_height = (a4_height - (num_rows + 1) * padding) / num_rows

    max_barcode_width = max(img.width for img in images)
    max_barcode_height = max(img.height for img in images)

    scale_factor = min(barcode_width / max_barcode_width, barcode_height / max_barcode_height)

    a4_img = Image.new('RGB', (int(a4_width), int(a4_height)), color='white')
    draw = ImageDraw.Draw(a4_img)

    for i, img in enumerate(images):
        row = i // num_columns
        col = i % num_columns
        x = int(padding + col * (barcode_width + padding))
        y = int(padding + row * (barcode_height + padding))
        img_resized = img.resize((int(img.width * scale_factor), int(img.height * scale_factor)))
        a4_img.paste(img_resized, (x, y))
    output_filename = os.path.join(output_directory, f'barcode_sheet_{len(os.listdir(output_directory))}.png')
    a4_img.save(output_filename)

def resize(img, text, padding):
    w, h = img.size
    new_img = Image.new('RGB', (w, h + padding), color='white')
    new_img.paste(img, (0, 0))
    draw = ImageDraw.Draw(new_img)
    font = ImageFont.truetype("arial.ttf", 16)
    t_bbox = draw.textbbox((0, 0), text, font=font)
    t_w, t_h = t_bbox[2] - t_bbox[0], t_bbox[3] - t_bbox[1]
    draw.text(((w - t_w) / 2, h), text, fill='black', font=font)
    return new_img

def codes_main(lines):
    text = [unidecode.unidecode(line.replace('\n', '')) for line in lines]

    data = [line.split(' ')[-1] for line in text]

    output_directory = 'Barkody'
    if not os.path.exists(output_directory):
        os.makedirs(output_directory)

    barcodes_per_page = 12
    for i in range(0, len(data), barcodes_per_page):
        generate(data[i:i+barcodes_per_page], text[i:i+barcodes_per_page], output_directory)

