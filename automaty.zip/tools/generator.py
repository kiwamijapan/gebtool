from openpyxl import load_workbook
from os import mkdir
from os.path import exists
from pandas import read_excel
from tkinter import messagebox

class Generator:
	def __init__(self, name):
		self.name = name
		self.df = read_excel('raw.xlsx')
		self.database_dir = 'tools/templates/database.xlsx'
		self.index_dir = 'tools/templates/index.xlsx'
		self.master_dir = 'tools/templates/masterdata.xlsx'

	def database(self):
		wb = load_workbook(filename=self.database_dir)
		ws = wb.active
		i = 3
		for x in range(len(self.df)):
			ws[f'A{i}'] = self.df['SAP'][x]
			ws[f'F{i}'] = self.df['SERIAL'][x]
			ws[f'G{i}'] = self.df['PL'][x]
			ws[f'H{i}'] = len(self.df['PL'][x])
			ws[f'I{i}'] = self.df['EN'][x]
			ws[f'J{i}'] = len(self.df['EN'][x])
			ws[f'AB{i}'] = self.df['TXT'][x]
			i += 1
		if not exists(f'Tabele/{self.name}'):
			mkdir(f'Tabele/{self.name}')
		wb.save(f'Tabele/{self.name}/{self.name} bazadanych.xlsx')
		print(f'Tabela bazy danych wygenerowana w folderze Tabele/{self.name}')		

	def update_database(self, column, ids, updated_data):
		wb = load_workbook(filename=f'Tabele/{self.name}/{self.name} bazadanych.xlsx')
		ws = wb.active
		
		column_mapping = {
		'SAP': 'A',
		'DOSTAWCA': 'B',
		'PRODUCENT': 'E',
		'NR SERYJNY': 'F',
		'OPIS PL': 'G',
		'OPIS EN': 'I',
		'CENA': 'L',
		'MAKSYMALNY POZIOM ZAPASOW': 'S',
		'POZIOM NASTEPNEGO ZAMOWIENIA': 'T',
		'MOQ': 'U',
		'MASA NETTO': 'Z',
		'MASA BRUTTO': 'AA',
		'TEKST ZAMOWIENIA': 'AB'
		}
		if column not in column_mapping:
			messagebox.showerror("Error", f"Invalid column '{column}'")
			return
		
		column_letter = column_mapping[column.upper()]
		ids_list = ids.split()
		updated_data_list = updated_data.split()
		
		if len(ids_list) != len(updated_data_list):
			messagebox.showerror("Error", "Number of IDs and updated data entries must match")
			return
		
		for row in ws.iter_rows(min_row=3, max_row=ws.max_row):
			cell = row[0]  # Assuming the first column has the IDs
			if cell.value in ids_list:
				index = ids_list.index(cell.value)
				ws[f'{column_letter}{cell.row}'] = updated_data_list[index]
		
		if not exists(f'Tabele/{self.name}'):
			os.mkdir(f'Tabele/{self.name}')
		
		wb.save(f'Tabele/{self.name}/{self.name} bazadanych.xlsx')
		messagebox.showinfo("Success", f"Database table updated in folder Tabele/{self.name}")

	def index_data(self):
		wb = load_workbook(filename=self.index_dir)
		ws = wb.active
		i = 8
		for x in range(len(self.df)):
			ws[f'A{i}'] = '6211'
			ws[f'B{i}'] = str(self.df['SAP'][x]).replace('-', '')
			ws[f'C{i}'] = self.df['SAP'][x]
			ws[f'F{i}'] = 'PL'
			ws[f'G{i}'] = self.df['PL'][x]
			ws[f'J{i}'] = 'SZT'
			ws[f'K{i}'] = 'HIBE'
			ws[f'N{i}'] = '0,002'
			ws[f'O{i}'] = '0,001'
			ws[f'P{i}'] = 'KG'
			ws[f'V{i}'] = 'PRD_NR'
			ws[f'W{i}'] = '8400'
			ws[f'AE{i}'] = self.df['EN'][x]
			ws[f'AF{i}'] = self.df['PL'][x]
			i+= 1
		if not exists(f'Tabele/{self.name}'):
			mkdir(f'Tabele/{self.name}')
		wb.save(f'Tabele/{self.name}/{self.name}.xlsx')
		print(f'Tabela indeksow wygenerowana w folderze Tabele/{self.name}')

	def master_data(self):
		wb = load_workbook(filename=self.master_dir)
		ws = wb.active
		i = 3
		for x in self.df['SAP']:
			ws[f'A{i}'] = x
			ws[f'B{i}'] = '6211'
			ws[f'C{i}'] = '0000'
			ws[f'D{i}'] = '0000'
			ws[f'E{i}'] = '621300'
			i += 1
		if not exists(f'Tabele/{self.name}'):
			mkdir(f'Tabele/{self.name}')
		wb.save(f'Tabele/{self.name}/{self.name} dane ogolne.xlsx')
		print(f'tabela danych ogolnych wygenerowana w folderze Tabele/{self.name}')		