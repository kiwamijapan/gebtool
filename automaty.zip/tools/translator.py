import deepl
class Translator:
	def __init__(self, lang, auth_key):
		self. lang = lang
		self.auth_key = auth_key

	def translate(self):
		data = self.load_data()
		translator = deepl.Translator(self.auth_key)
		with open('Tlumacz/tlumacz_out.txt', 'w', encoding='utf-8') as f:
			for entry in data:
				with translator.translate_text(entry, target_lang=self.lang) as output:
					f.write(f'{output} !{len(output)}!' if len(output) > 40 else output)
		print("indeksy przetlumaczone.")
		
	
	@staticmethod
	def load_data():
		try:
			with open('Tlumacz/tlumacz_in.txt', encoding='utf-8') as f:
				data = f.readlines()
			if not data:
				print("Plik wejsciowy jest pusty!")
				quit()
			else:
				return data
		except FileNotFoundError:
			print("Plik wejsciowy nie istnieje. Utworz plik o nazwie 'tlumacz_in.txt' w folderze Tlumacz.")
		