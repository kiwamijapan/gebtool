from tools.generator import Generator
from tools.translator import Translator
from tools.barcoder import *
import os
import tkinter as tk
from tkinter import ttk, messagebox

def generate():
	print("Generator indeksow v1.0.0 by toima.")
	name = input("wprowadz nazwe maszyny: ")
	while name == '':
		name = input("Nazwa nie moze byc pusta. sprobuj jeszcze raz: ")
	generator = Generator(name)
	choice = input("Czy uzyte numery sa nowe? (t/n)")
	while choice not in ['t', 'T', 'n', 'N']:
		choice = input("wprowadz poprawna odpowiedz.")
	if choice.lower() == 'y':
		generator.master_data()
	generator.index_data()
	generator.database()

def list_subdirectories():
	return {idx + 1: d for idx, d in enumerate(os.listdir('Tabele')) if os.path.isdir(os.path.join('Tabele', d))}

def update():
    def submit_update():
        selected_subdir = subdir_combobox.get()
        if not selected_subdir:
            messagebox.showerror("Error", "Please select a subdirectory")
            return
        
        name = selected_subdir
        column = column_combobox.get()
        ids = ids_text.get("1.0", tk.END).strip()
        updated_data = data_text.get("1.0", tk.END).strip()
        
        if not column:
            messagebox.showerror("Error", "Please select a column")
            return
        
        if not ids or not updated_data:
            messagebox.showerror("Error", "Please enter IDs and data to be updated")
            return
        
        generator = Generator(name)
        generator.update_database(column, ids, updated_data)
    
    update_window = tk.Tk()
    update_window.title("Update Database")

    subdirectories = list_subdirectories()
    subdir_combobox = ttk.Combobox(update_window, values=list(subdirectories.values()), state="readonly")
    subdir_combobox.grid(row=0, column=1, padx=10, pady=5)
    tk.Label(update_window, text="Select Subdirectory:").grid(row=0, column=0, padx=10, pady=5)

    columns = ['CENA', 'DOSTAWCA', 'PRODUCENT', 'MAKSYMALNY POZIOM ZAPASOW', 'POZIOM NASTEPNEGO ZAMOWIENIA', 'MOQ', 'MASA NETTO', 'MASA BRUTTO', 'TEKST ZAMOWIEINIA']
    column_combobox = ttk.Combobox(update_window, values=columns, state="readonly")
    column_combobox.grid(row=1, column=1, padx=10, pady=5)
    tk.Label(update_window, text="Select Column:").grid(row=1, column=0, padx=10, pady=5)

    tk.Label(update_window, text="Paste IDs:").grid(row=2, column=0, padx=10, pady=5)
    ids_text = tk.Text(update_window, height=10, width=50)
    ids_text.grid(row=2, column=1, padx=10, pady=5)

    tk.Label(update_window, text="Paste Data to be Updated:").grid(row=3, column=0, padx=10, pady=5)
    data_text = tk.Text(update_window, height=10, width=50)
    data_text.grid(row=3, column=1, padx=10, pady=5)

    submit_button = tk.Button(update_window, text="Update", command=submit_update)
    submit_button.grid(row=4, column=1, padx=10, pady=10)

    update_window.mainloop()

def translate():
	print("tlumacz indeksow v1.0.0 by toima. UWAGA! deepl w przypadku problemu z tlumaczeniem zwraca oryginalna wartosc! !!!MOGA POJAWIC SIE NIEPRZETLUMACZONE WARTOSCI!!!")
	lang = input("Wprowadz jezyk docelowy (EN-US, PL, INNY KOD ISO): ")
	try:
		with open('Tlumacz/api-key.txt') as f:
			auth_key = f.readlines()[0]
		if not auth_key:
			print("Brak klucza! uzupelnij plik api-key.txt w folderze Tlumacz.")
			main()
	except FileNotFoundError:
		print("Plik klucza nie istnieje! stworz plik api-key.txt w folderze Tlumacz i wklej do niego swoj klucz.")
	translator = Translator(lang, auth_key)
	translator.translate()

def barcodes():
	root = tk.Tk()
	app = KeyDescriptionApp(root)
	root.mainloop()

def main():
	while True:
		choice = input("---------- Tools by toima ----------\n\t Wybierz opcje: \t\t\n\t1. Tworzenie arkuszy \t\t\n\t2. Tlumaczenie indeksow\t\t\n\t3. Generator kodow kreskowych\t\t\n\t4. Aktualizacja bazy danych\t\t\n\t5. Wyjscie\t\t\n\tWpisz help aby wyswietlic instrukcje\t\t\n------------------------------------\n")
		while choice not in ['1', '2', '3', '4', '5', 'help']:
			choice = input("Niepoprawny wybor. Wybierz ponownie.\n")
		match choice:
			case '1':
				generate()
			case '2':
				# translate()
				print("usluga niedostepna. Siec blokuje dostep do API. Uzycie mozliwe tylko na zewnetrznym urzadzeniu. Chyba ze IT zmieni reguly w miedzyczasie.")
			case '3':
				barcodes()
			case '4':
				update()
			case '5':
				quit()
			case 'help':
				with open('PRZECZYTAJ.txt', encoding='utf-8') as f:
					print(f.read())

main()